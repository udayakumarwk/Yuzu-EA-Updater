
import java.awt.Color;
import java.awt.Desktop;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;

public class MainGui {

	private JFrame frmYuzuUpdater;
	private JTextArea statusValue;
	private JLabel latestVersionValue;
	static MainGui window;
	JLabel currentVersionValue;
	JProgressBar progressBar;
	JLabel downloadStatus;
	JComboBox<String> comboBox;
	List<String> versionList;
static final String APPVERSION = "V0.1";
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					checkStartUp();
					window = new MainGui();
					window.updateProgressLabelAndProgressBar("Version lists:", false);
					window.frmYuzuUpdater.setVisible(true);
					window.updateStatusValueIfNewVersionAvailable();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

		updateCurrentAndLatestVersion();
		

	}

	private static void updateCurrentAndLatestVersion() {
		SwingWorker<String, String> Lastetworker = new SwingWorker<String, String>() {

			@Override
			protected String doInBackground() throws Exception {
				String latestVersion = checkForUpdate();
				return latestVersion;
			}

			@Override
			protected void done() {
				try {
					MainGui.window.latestVersionValue.setText(get());
				} catch (InterruptedException e) {
					e.printStackTrace();
				} catch (ExecutionException e) {
					e.printStackTrace();
				}
			}

		};
		Lastetworker.execute();

		SwingWorker<String, String> currentWorker = new SwingWorker<String, String>() {

			@Override
			protected String doInBackground() throws Exception {
				String latestVersion = getCurrentVersion();
				return latestVersion;
			}

			@Override
			protected void done() {
				try {
					MainGui.window.currentVersionValue.setText(get());
				} catch (InterruptedException e) {
					e.printStackTrace();
				} catch (ExecutionException e) {
					e.printStackTrace();
				}
			}

		};
		currentWorker.execute();

	}

	/**
	 * Create the application.
	 */
	public MainGui() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmYuzuUpdater = new JFrame();
		frmYuzuUpdater.setResizable(false);
		frmYuzuUpdater.setTitle("Yuzu updater "+ APPVERSION);
		frmYuzuUpdater.setBounds(100, 100, 450, 300);
		frmYuzuUpdater.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmYuzuUpdater.getContentPane().setLayout(null);

		try {
			//UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			
			e.printStackTrace();
		} 
		JPanel row1 = new JPanel();
		row1.setBounds(0, 1, 436, 33);
		FlowLayout flowLayout = (FlowLayout) row1.getLayout();
		flowLayout.setVgap(10);
		flowLayout.setHgap(10);
		frmYuzuUpdater.getContentPane().add(row1);

		JLabel currentVersionLabel = new JLabel("Current Version:");
		row1.add(currentVersionLabel);

		currentVersionValue = new JLabel("?");
		currentVersionValue.setBackground(new Color(78, 209, 180));
		row1.add(currentVersionValue);

		JLabel latestVersionlabel = new JLabel("Latest Version:");
		row1.add(latestVersionlabel);

		latestVersionValue = new JLabel("?");
		row1.add(latestVersionValue);

		JPanel row2 = new JPanel();
		row2.setBounds(0, 40, 436, 44);
		frmYuzuUpdater.getContentPane().add(row2);
		row2.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

		downloadStatus = new JLabel("Download Status:");
		row2.add(downloadStatus);

		progressBar = new JProgressBar();
		row2.add(progressBar);
		disableProgressBar();
		comboBox = new JComboBox<String>();
		comboBox.setModel(new DefaultComboBoxModel<String>(new String[] { "no items" }));
		row2.add(comboBox);

		JButton updateAndLaunch = new JButton("update and launch");
		row2.add(updateAndLaunch);

		JPanel row3 = new JPanel();
		row3.setBounds(0, 86, 436, 53);
		frmYuzuUpdater.getContentPane().add(row3);

		JButton launchWithoutUpdate = new JButton("Launch Yuzu");
		launchWithoutUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if (launchYuzu()) {
						updateStatus("Launch Yuzu successfull...");
					} else {
						updateStatus("Failed to launch yuzu");
					}
				} catch (Exception e1) {

					e1.printStackTrace();
					updateStatus("Failed to launch yuzu \n" + e1.getLocalizedMessage());

				}
			}
		});

		JLabel statusLabel = new JLabel("Status:");
		row3.setLayout(new FlowLayout(FlowLayout.CENTER, 10000, 5));
		row3.add(launchWithoutUpdate);
		row3.add(statusLabel);

		JPanel row4 = new JPanel();
		row4.setBorder(new SoftBevelBorder(BevelBorder.RAISED, new Color(64, 128, 128), new Color(64, 128, 128),
				new Color(64, 128, 128), new Color(64, 128, 128)));
		row4.setBounds(0, 139, 436, 122);
		frmYuzuUpdater.getContentPane().add(row4);
		row4.setLayout(new BoxLayout(row4, BoxLayout.X_AXIS));

		statusValue = new JTextArea();
		statusValue.setBackground(new Color(192, 192, 192));
		statusValue.setRows(3);
		statusValue.setEditable(false);
		statusValue.setText("-");
		statusValue.setWrapStyleWord(true);
		statusValue.setLineWrap(true);
		row4.add(statusValue);

		updateAndLaunch.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				updateAndLaunchFun();
			}

		});

	}

	protected void updateAndLaunchFun() {

		boolean isDownloadRequired = false;
		try {
			if (!isOutdated(this.comboBox.getSelectedItem().toString().trim())) {

				try {
					if (launchYuzu()) {
						updateStatus("Launch Yuzu successful...");
					} else {
						updateStatus("Failed to launch yuzu");
					}
				} catch (Exception e) {
					if (e.getMessage().contains("doesn't exist")) {
						updateStatus(e.getMessage() + "\n" + "redownloading..");
						isDownloadRequired = true;
					}
				}

			}

			// download and extract

			// download
			if (isDownloadRequired || isOutdated(this.comboBox.getSelectedItem().toString().trim())) {
				String downloadLink = "https://github.com/pineappleEA/pineapple-src/releases/download/"
						+ this.comboBox.getSelectedItem().toString().trim() + "/Windows-Yuzu-"
						+ this.comboBox.getSelectedItem().toString().trim().trim() + ".zip";
				updateStatus("Using download link \n" + downloadLink);
				MainGui.window.progressBar.setValue(0);
				SwingWorker<Void, Integer> downloader = new SwingWorker<Void, Integer>() {

					@Override
					protected Void doInBackground() throws Exception {

						updateProgressLabelAndProgressBar("DownloadStatus:", true);

						File file = new File("yuzu-update.zip");
						if (file.exists()) {
							file.delete();
							file.createNewFile();
						} else {
							file.createNewFile();
						}

						URL url = new URL(downloadLink);
						URLConnection urlConnection = url.openConnection();
						System.out.println("Date= " + new Date(urlConnection.getLastModified()));
						updateStatus("Size= " + urlConnection.getContentLength());
						BufferedInputStream bis = new BufferedInputStream(url.openStream());

						FileOutputStream fis = new FileOutputStream(file);
						byte[] buffer = new byte[1024];
						int count = 0, countTracker = 0, percentOld = 0, percentNew = 1;

						while ((count = bis.read(buffer, 0, 1024)) != -1) {
							countTracker += count;
							percentNew = ((int) (countTracker / (float) urlConnection.getContentLength() * 100));
							if (percentOld != percentNew) {
								percentOld = percentNew;
								updateStatus("Downloading progress " + percentOld + "%");
								publish(percentOld);

							}
							fis.write(buffer, 0, count);

						}
						fis.close();
						bis.close();
						updateProgressLabelAndProgressBar("Version lists:", false);
						
						return null;
					}

					@Override
					protected void process(List<Integer> chunks) {
						MainGui.window.progressBar.setValue(chunks.get(chunks.size() - 1));

					}

				};

				downloader.execute();

				updatedConfig(MainGui.window.comboBox.getSelectedItem().toString());

				// extract
				SwingWorker<Void, Void> extractor = new SwingWorker<Void, Void>() {

					@Override
					protected Void doInBackground() throws Exception {
						while (true) {
							if (downloader.isDone()) {
								break;
							}
							Thread.currentThread();
							Thread.sleep(3000);
						}

						File file = new File("yuzu-update.zip");
						String destDir = "./Yuzu";
						File destDirFile = new File(destDir);
						updateStatus("Deleting old files " + destDirFile.getAbsolutePath());
						updateStatus("Extracting " + file.getName());
						deleteOldFiles(destDirFile);
						unzip(file.getAbsolutePath(), destDir);
						if (launchYuzu()) {
							updateStatus("Launch Yuzu successful...");
						} else {
							updateStatus("Failed to launch yuzu");
						}
						MainGui.window.currentVersionValue.setText(MainGui.window.latestVersionValue.getText());
						window.updateStatusValueIfNewVersionAvailable();
						return null;

					}

				};

				extractor.execute();

			}
			

		} catch (Exception e1) {

			e1.printStackTrace();
			updateStatus("Failed to launch yuzu \n" + e1.getLocalizedMessage());
			window.updateStatusValueIfNewVersionAvailable();

		}

	}

	private void updateStatus(String status) {
		System.out.println(status);
		statusValue.setText(status);

	}

	public static void checkStartUp() throws IOException {
		File config = new File("config");
		if (!config.exists()) {
			config.createNewFile();
		}
	}

	public static void unzip(String zipFile, String extractFolder) {
		try {
			int BUFFER = 2048;
			File file = new File(zipFile);

			ZipFile zip = new ZipFile(file);
			String newPath = extractFolder;

			new File(newPath).mkdir();
			Enumeration zipFileEntries = zip.entries();

			// Process each entry
			while (zipFileEntries.hasMoreElements()) {
				// grab a zip file entry
				ZipEntry entry = (ZipEntry) zipFileEntries.nextElement();
				String currentEntry = entry.getName();

				File destFile = new File(newPath, currentEntry);
				// destFile = new File(newPath, destFile.getName());
				File destinationParent = destFile.getParentFile();

				// create the parent directory structure if needed
				destinationParent.mkdirs();

				if (!entry.isDirectory()) {
					BufferedInputStream is = new BufferedInputStream(zip.getInputStream(entry));
					int currentByte;
					// establish buffer for writing file
					byte data[] = new byte[BUFFER];

					// write the current file to disk
					FileOutputStream fos = new FileOutputStream(destFile);
					BufferedOutputStream dest = new BufferedOutputStream(fos, BUFFER);

					// read and write until last byte is encountered
					while ((currentByte = is.read(data, 0, BUFFER)) != -1) {
						dest.write(data, 0, currentByte);
					}
					dest.flush();
					dest.close();
					is.close();
				}

			}
			System.out.println("Extraction complete");
			window.updateStatusValueIfNewVersionAvailable();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Failed to Unzip :(");
			window.updateStatusValueIfNewVersionAvailable();
		}

	}

	public static void deleteOldFiles(File destDirFile) {
		deleteDirectory(destDirFile);
		destDirFile.delete();
	}

	public static void deleteDirectory(File file) {

		if (!file.exists())
			return;
		for (File subfile : file.listFiles()) {
			if (subfile.isDirectory()) {
				deleteDirectory(subfile);
			}
			subfile.delete();
		}
	}

	public static boolean launchYuzu() throws IOException {
		window.updateProgressLabelAndProgressBar("Version lists:", false);
		
		String currentDir = System.getProperty("user.dir");
		System.out.println("Current dir using System:" + currentDir);
		if (!new File("./Yuzu/").exists()) {
			updatedConfig("");
			MainGui.window.updateStatus(
					"Yuzu folder doesn't exist. Please use Update and Launch to download latest version...");
		}
		System.out.println("Launching Yuzu");

//        Runtime.getRuntime().exec("yuzu.exe",
//                null, new File(currentDir+"/Yuzu/yuzu-windows-msvc-early-access/"));
		try {
			Desktop desktop = Desktop.getDesktop();
			desktop.open(new File(currentDir + "/Yuzu/yuzu-windows-msvc-early-access/yuzu.exe"));
		} catch (java.lang.IllegalArgumentException e) {
			throw e;

		}
		return true;
	}

	public static void updatedConfig(String toWrite) throws IOException {
		Path fileName = Path.of("config");
		Files.writeString(fileName, toWrite, StandardCharsets.UTF_8);
		try {
			window.currentVersionValue.setText(toWrite);
		}catch(Exception ignore) {}
	}

	public static boolean isOutdated(String version) throws IOException {

		String str = getCurrentVersion();
		if (str.trim().equals(version)) {
			return false;

		}
		return true;
	}

	public static String getCurrentVersion() throws IOException {
		Path fileName = Path.of("config");
		if (!new File("./Yuzu").exists()) {
			updatedConfig("");
		}
		String str = "?";
		try {
			str = Files.readString(fileName);
		} catch (IOException e) {

			e.printStackTrace();

		}
		if (str.trim().isEmpty() || str.trim().equals("?")) {
			return "Not Found";
		}
		return str;
	}

	public static String checkForUpdate() {
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest request = HttpRequest.newBuilder().uri(URI.create("https://pineappleea.github.io/")).GET().build();

		HttpResponse<String> response = null;
		try {
			response = client.send(request, HttpResponse.BodyHandlers.ofString());
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}

		String body = response.body();

		body = body.substring(body.indexOf("<!--link-goes-here-->") + ("<!--link-goes-here-->".length() + 1));
		body = body.substring(0, body.indexOf("</div>"));
		String latestVersion = body.split("<br>")[0];
		System.out.println(latestVersion);

		String versionlistTag[] = body.split("<br>");

		List<String> versions = new ArrayList<String>();
		for (String version : versionlistTag) {
			if (version.trim().isEmpty())
				continue;
			String v = version.substring(version.indexOf(">") + 1, version.lastIndexOf("<"));
			StringBuilder sb = new StringBuilder();
			sb.append(v.split(" ")[1]);
			sb.append("-");
			sb.append(v.split(" ")[2]);
			versions.add(sb.toString());
		}

		updateComboBox(versions);

		latestVersion = latestVersion.substring(latestVersion.indexOf(">") + 1, latestVersion.lastIndexOf("<"));
		String latestVerstionLink = body.substring(body.indexOf("href="), body.indexOf(">"));
		;
		latestVerstionLink = latestVerstionLink.split("=")[1];
		System.out.println(latestVersion);
		System.out.println(latestVerstionLink);
		StringBuilder sb = new StringBuilder();
//     sb.append(latestVersion.split(" ")[0]);
//     sb.append("-");
		sb.append(latestVersion.split(" ")[1]);
		sb.append("-");
		sb.append(latestVersion.split(" ")[2]);
		System.out.println(sb.toString());

		return sb.toString();

	}

	private static void updateComboBox(List<String> versions) {
		window.comboBox.setModel(new DefaultComboBoxModel(versions.toArray()));
		try {
			window.comboBox.setSelectedItem(getCurrentVersion().trim());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void enableProgressBar() {
		progressBar.setVisible(true);
	}

	private void disableProgressBar() {
		progressBar.setVisible(false);
	}

	private void enableComboBox() {
		comboBox.setVisible(true);
	}

	private void disableComboBox() {
		comboBox.setVisible(false);
	}

	private void updateProgressLabelAndProgressBar(String labelText, boolean isProgressBar) {
		downloadStatus.setText(labelText);

		if (isProgressBar) {
			enableProgressBar();
			disableComboBox();
		} else {
			disableProgressBar();
			enableComboBox();
		}

	}
	
	private  void updateStatusValueIfNewVersionAvailable() {
		
		SwingWorker<String, String> Latestworker = new SwingWorker<String, String>() {

			@Override
			protected String doInBackground() throws Exception {
				String latestVersion = checkForUpdate();
				return latestVersion;
			}

			@Override
			protected void done() {
				try {
					if(!getCurrentVersion().equals(get())) {
						updateStatus("NEWER VERSION AVAILABlE!!!!! CURRENT VERSION = "+getCurrentVersion()+" NEWER VERSION = "+get());
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		};
		Latestworker.execute();
		
	}
}
