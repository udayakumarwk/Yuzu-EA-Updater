#!/bin/bash

javac src/MainGui.java
java -classpath src MainGui